﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace A17
{
    public partial class Form2 : Form
    {
        string connStr = "server=localhost; user=root; password=12345; database = a17";
        MySqlConnection conn = null;
        MySqlDataAdapter da = null;
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            chart1.Series[0].ChartType = SeriesChartType.Pie;
            chart1.Series[0].IsValueShownAsLabel = true;
            chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
                string sql = "SELECT * FROM modell ORDER BY ModellID ASC";
                da = new MySqlDataAdapter(sql, conn);
                da.Fill(dt);
                comboBox1.DataSource = dt;
                comboBox1.DisplayMember = "Modell";
                comboBox1.ValueMember = "ModellID";
            }
            catch { MessageBox.Show("Adatbázis kapcsolódási hiba!"); }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e) //Kilepes
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e) //Megjelenites
        {
            try
            {
                conn.Open();
                string sql = "SELECT GyartasiEv AS 'Gyártási év', CAST(AVG(Ar) AS DECIMAL(10,2)) AS 'Átlag ár' FROM  jarmu WHERE ModellID=" + comboBox1.SelectedValue + " GROUP BY GyartasiEv";
                da.SelectCommand.CommandText = sql;
                dt1.Clear();
                da.Fill(dt1);
                dataGridView1.DataSource = dt1;
                chart1.DataSource = dt1;
                chart1.Series[0].XValueMember = "Gyártási év";
                chart1.Series[0].YValueMembers = "Átlag ár";
                chart1.DataBind();
            }
            catch { MessageBox.Show("Hiba!"); }
            conn.Close();
        }
    }
}
