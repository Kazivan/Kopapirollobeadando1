﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A17
{
    public partial class Form1 : Form
    {
        string connStr = "server=localhost; user=root; password=12345; database = a17";
        MySqlConnection conn = null;
        MySqlDataAdapter da = null;
        MySqlCommand cmd = null;
        DataTable dt = new DataTable(); //jarmu
        DataTable dt1 = new DataTable(); // modell
        DataTable dt2 = new DataTable(); // szin
        DataTable dt3 = new DataTable(); //uzemanyag
        DataTable dt4 = new DataTable();
        List<String> list1 = new List<string>();
        int index;
        bool elindult = false; // ne induljon a textBox1_TextChanged a megnyitaskor
        public Form1()
        {
            InitializeComponent();
        }

        private void kilépésToolStripMenuItem_Click(object sender, EventArgs e) //Kilepes
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            változtatásToolStripMenuItem.Enabled = false;
            button2.Visible = false;
            try
            {
                conn = new MySqlConnection(connStr);
                cmd = new MySqlCommand("", conn);
                conn.Open();
                string sql = "SELECT * FROM jarmu ORDER BY JarmuID ASC";
                da = new MySqlDataAdapter(sql, conn);
                da.Fill(dt);
                string sql1 = "SELECT * FROM modell ORDER BY ModellID ASC";
                da.SelectCommand.CommandText = sql1;
                da.Fill(dt1);
                comboBox1.DataSource = dt1;
                comboBox1.DisplayMember = "Modell";
                comboBox1.ValueMember = "ModellID";
                string sql2 = "SELECT * FROM szin ORDER BY SzinID ASC";
                da.SelectCommand.CommandText = sql2;
                da.Fill(dt2);
                comboBox2.DataSource = dt2;
                comboBox2.DisplayMember = "Szin";
                comboBox2.ValueMember = "SzinID";
                string sql3 = "SELECT * FROM uzemanyag ORDER BY UzemanyagID ASC";
                da.SelectCommand.CommandText = sql3;
                da.Fill(dt3);
                comboBox3.DataSource = dt3;
                comboBox3.DisplayMember = "Uzemanyag";
                comboBox3.ValueMember = "UzemanyagID";
                textBox1.Text = dt.Rows[0][0].ToString();
                textBox2.Text = dt.Rows[0][1].ToString();
                textBox3.Text = dt.Rows[0][2].ToString();
                textBox4.Text = dt.Rows[0][3].ToString();
                textBox5.Text = dt.Rows[0][7].ToString().Replace(',', '.');
                comboBox1.SelectedValue = dt.Rows[0][4];
                comboBox2.SelectedValue = dt.Rows[0][5];
                comboBox3.SelectedValue = dt.Rows[0][6];
                for (int i = 0; i < dt.Rows.Count; i++)
                    list1.Add(dt.Rows[i][0].ToString() + "\t" + dt.Rows[i][1].ToString() + "\t" + dt.Rows[i][2].ToString() + "\t\t" + dt.Rows[i][3].ToString() + "\t\t" + dt.Rows[i][4].ToString() + "\t\t" + dt.Rows[i][5].ToString() + "\t\t" + dt.Rows[i][6].ToString() + "\t\t" + dt.Rows[i][7].ToString());
                listBox1.DataSource = list1;
                index = listBox1.SelectedIndex;
                elindult = true;
            }
            catch { MessageBox.Show("Adatbázis kapcsolódási hiba!"); }
            conn.Close();

        }

        private void analizisToolStripMenuItem_Click(object sender, EventArgs e) //Analizis
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void azAlkalmazásrólToolStripMenuItem_Click(object sender, EventArgs e) //Az alkalmazasrol
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) // Jarmu valasztas
        {
            if (listBox1.SelectedIndex >= 0)
                index = listBox1.SelectedIndex;
            textBox1.Text = dt.Rows[index][0].ToString();
            textBox2.Text = dt.Rows[index][1].ToString();
            textBox3.Text = dt.Rows[index][2].ToString();
            textBox4.Text = dt.Rows[index][3].ToString();
            textBox5.Text = dt.Rows[index][7].ToString().Replace(',', '.');
            comboBox1.SelectedValue = dt.Rows[index][4];
            comboBox2.SelectedValue = dt.Rows[index][5];
            comboBox3.SelectedValue = dt.Rows[index][6];
        }

        private void textBox1_TextChanged(object sender, EventArgs e) // Azonosito valtoztatasa 
        {
            if (elindult)
            {
                try
                {
                    if (textBox1.Text != "")
                    {
                        conn.Open();
                        int x = Convert.ToInt32(textBox1.Text);
                        string sql = "SELECT * FROM jarmu WHERE JarmuID=" + textBox1.Text;
                        da.SelectCommand.CommandText = sql;
                        dt4.Clear();
                        da.Fill(dt4);
                        if (dt4.Rows.Count > 0)
                        {
                            textBox2.Text = dt4.Rows[0][1].ToString();
                            textBox3.Text = dt4.Rows[0][2].ToString();
                            textBox4.Text = dt4.Rows[0][3].ToString();
                            textBox5.Text =dt4.Rows[0][7].ToString().Replace(',','.');
                            comboBox1.SelectedValue = dt4.Rows[0][4];
                            comboBox2.SelectedValue = dt4.Rows[0][5];
                            comboBox3.SelectedValue = dt4.Rows[0][6];
                        }
                        else
                        {
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            textBox5.Text = "";
                            comboBox1.SelectedIndex = -1;
                            comboBox2.SelectedIndex = -1;
                            comboBox3.SelectedIndex = -1;
                        }
                    }
                    else
                    {
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        comboBox1.SelectedIndex = -1;
                        comboBox2.SelectedIndex = -1;
                        comboBox3.SelectedIndex = -1;
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Az Azonosító egész szám kell hogy legyen!");
                    textBox1.Clear();
                }
                catch { MessageBox.Show("Adatbázis kapcsolódási hiba!"); }
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e) //Felkeszules a valtoztatasra
        {
            button2.Visible = true;
            textBox1.ReadOnly = true;
            listBox1.Enabled = false;
            button1.Enabled = false;
            változtatásToolStripMenuItem.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e) //Megse
        {
            button2.Visible = false;
            textBox1.ReadOnly = false;
            listBox1.Enabled = true;
            button1.Enabled = true;
            változtatásToolStripMenuItem.Enabled = false;
        }

        private void változtatásToolStripMenuItem_Click(object sender, EventArgs e) //Valtoztatas
        {
            DialogResult res = MessageBox.Show("Biztos változtatni akarsz?", "Változtatás!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                try
                {
                    if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
                    {
                        conn.Open();
                        string sql = "UPDATE jarmu SET Regisztracio='" + textBox2.Text + "', GyartasiEv=" + textBox3.Text + ", MegtettKM=" + textBox4.Text + ", Ar=" + textBox5.Text + ", ModellID=" + comboBox1.SelectedValue + ", SzinID=" + comboBox2.SelectedValue + ", UzemanyagID=" + comboBox3.SelectedValue + " WHERE JarmuID= " + textBox1.Text;
                        cmd.CommandText = sql;
                        if (cmd.ExecuteNonQuery() == 1)
                        {
                            MessageBox.Show("A változtatás sikerült!");
                            string sql1 = "SELECT * FROM jarmu ORDER BY JarmuID ASC";
                            da.SelectCommand.CommandText = sql1;
                            dt.Clear();
                            da.Fill(dt);
                            list1.Clear();
                            for (int i = 0; i < dt.Rows.Count; i++)
                                list1.Add(dt.Rows[i][0].ToString() + "\t" + dt.Rows[i][1].ToString() + "\t" + dt.Rows[i][2].ToString() + "\t\t" + dt.Rows[i][3].ToString() + "\t\t" + dt.Rows[i][4].ToString() + "\t\t" + dt.Rows[i][5].ToString() + "\t\t" + dt.Rows[i][6].ToString() + "\t\t" + dt.Rows[i][7].ToString());
                            listBox1.DataSource = null;
                            listBox1.DataSource = list1;
                            button2.Visible = false;
                            textBox1.ReadOnly = false;
                            listBox1.Enabled = true;
                            button1.Enabled = true;
                            változtatásToolStripMenuItem.Enabled = false;
                        }
                        else
                            MessageBox.Show("A változtatás nem sikerült!");
                    }
                    else
                    { MessageBox.Show("Minden mezőt ki kell tölteni!"); }
                }
                catch
                {
                    MessageBox.Show("Hiba!");
                }
                conn.Close();
            }
        }
    }
}
