﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace A18
{
    public partial class Form2 : Form
    {
        string connStr = "server=192.168.10.21; user=33aaaa; password=12345; database = 33aaaa_a18";
        MySqlConnection conn = null;
        MySqlDataAdapter da = null;
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            chart1.Series[0].ChartType = SeriesChartType.Pie;
            chart1.Series[0].IsValueShownAsLabel = true;
            chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            try
            {
                conn = new MySqlConnection(connStr);
                conn.Open();
                string sql = "";
                da = new MySqlDataAdapter(sql, conn);
            }
            catch { MessageBox.Show("Adatbázis kapcsolódási hiba!"); }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e) //kilepes
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e) //Mutasd
        {
            try
            {
                int min = Convert.ToInt32(textBox1.Text);
                int max = Convert.ToInt32(textBox2.Text);
                conn.Open();
                string sql = "SELECT JarmuID, Regisztracio, GyartasiEv, MegtettKM, Ar FROM  jarmu WHERE Ar>=" + min + " AND Ar<=" + max;
                da.SelectCommand.CommandText = sql;
                dt.Clear();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                string sql1 = "SELECT modell.Modell AS Modell, COUNT(jarmu.JarmuID) AS Szam  FROM  jarmu, modell WHERE jarmu.ModellID=modell.ModellID AND Ar>=" + min + " AND Ar<=" + max + " GROUP BY modell.ModellID";
                da.SelectCommand.CommandText = sql1;
                dt1.Clear();
                da.Fill(dt1);
                chart1.DataSource = dt1;
                chart1.Series[0].XValueMember = "Modell";
                chart1.Series[0].YValueMembers = "Szam";
                chart1.DataBind();
            }
            catch (FormatException)
            {
                MessageBox.Show("Egész szá szükséges!");
            }
            catch { MessageBox.Show("Hiba!"); }
            conn.Close();
        }
    }
}
