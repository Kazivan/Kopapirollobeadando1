-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Jan 04. 11:54
-- Kiszolgáló verziója: 10.4.21-MariaDB
-- PHP verzió: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `33hodi_a17`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felszereles`
--

CREATE TABLE `felszereles` (
  `FelszerelesID` int(11) NOT NULL,
  `Elnevezes` varchar(20) DEFAULT NULL,
  `Leiras` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `gyarto`
--

CREATE TABLE `gyarto` (
  `GyartoID` int(11) NOT NULL,
  `Gyarto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `gyarto`
--

INSERT INTO `gyarto` (`GyartoID`, `Gyarto`) VALUES
(1, 'Opel'),
(2, 'BMW'),
(3, 'Mercedes'),
(4, 'Ferari'),
(5, 'Fiat'),
(6, 'Hjundai'),
(7, 'Kia'),
(8, 'Folksvagen');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jarmu`
--

CREATE TABLE `jarmu` (
  `JarmuID` int(11) NOT NULL,
  `Regisztracio` varchar(20) NOT NULL,
  `GyartasiEv` int(11) NOT NULL,
  `MegtettKM` int(11) NOT NULL,
  `ModellID` int(11) NOT NULL,
  `SzinID` int(11) NOT NULL,
  `UzemanyagID` int(11) NOT NULL,
  `Ar` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `jarmu`
--

INSERT INTO `jarmu` (`JarmuID`, `Regisztracio`, `GyartasiEv`, `MegtettKM`, `ModellID`, `SzinID`, `UzemanyagID`, `Ar`) VALUES
(1, 'BC-101-MN', 2011, 80000, 1, 3, 3, '500000.25'),
(2, 'BG-258-MN', 2012, 5000, 7, 4, 1, '556200.00'),
(3, 'BG-147-MK', 2015, 1500, 10, 5, 1, '874320.00'),
(4, 'NS-251-FV', 2005, 9000, 14, 6, 1, '320000.00'),
(5, 'SA-251-GT', 2010, 6700, 2, 1, 1, '500000.00'),
(6, 'NS-582-MJ', 2001, 13000, 3, 2, 2, '150000.00'),
(7, 'BC-214-NN', 2003, 31000, 4, 2, 4, '112300.00'),
(8, 'BC-369 - FF', 2007, 21000, 3, 1, 4, '254989.00'),
(9, 'NS-247-FR', 2011, 19000, 6, 4, 2, '763520.00'),
(10, 'BG-852-JU', 2010, 5000, 6, 3, 2, '698533.00'),
(11, 'NS-879 -JJ', 2008, 12000, 5, 5, 1, '400000.00'),
(12, 'SA-125-MM', 2009, 40000, 4, 3, 2, '410000.00'),
(13, 'BG-528-BB', 2009, 5000, 6, 5, 1, '422000.00'),
(14, 'NS-548-FR', 2010, 7620, 4, 7, 4, '650000.00'),
(15, 'BC-258-SS', 2009, 21000, 14, 4, 2, '555000.00'),
(16, 'BG-258-CF', 2011, 7850, 7, 6, 3, '699999.00'),
(17, 'NS-584 - KI', 2010, 7850, 4, 3, 2, '589000.00'),
(18, 'NS-256-TR', 2011, 9800, 3, 2, 3, '499999.00'),
(19, 'BG-247-AA', 2015, 6580, 1, 1, 3, '845000.00'),
(20, 'BG-789-EW', 2010, 6540, 2, 6, 3, '690000.00'),
(21, 'BG-254-VF', 2015, 4210, 10, 8, 3, '950500.00'),
(22, 'BG-444-WQ', 2011, 6300, 10, 8, 3, '700000.00'),
(23, 'NS-698-CD', 2010, 5400, 12, 7, 3, '456060.00'),
(24, 'NS-147-BG', 2011, 7800, 13, 6, 2, '456654.00'),
(25, 'NS-617-TX', 2001, 9000, 1, 1, 4, '100000.00'),
(26, 'BG-987 -JJ', 2001, 25000, 2, 6, 4, '99000.00'),
(27, 'NS-141-FF', 2003, 14000, 2, 7, 4, '99999.00'),
(28, 'BC-658 -JY', 2008, 13000, 13, 8, 4, '299000.00'),
(29, 'BG-888-HH', 2007, 5000, 10, 2, 3, '245500.00'),
(30, 'BG-988-EE', 2008, 15000, 12, 6, 3, '275400.00'),
(31, 'NS-625-UJ', 2006, 31000, 5, 4, 1, '233600.00'),
(32, 'BG-555-SS', 2010, 11000, 11, 5, 1, '410000.00'),
(33, 'NS-633-SQ', 2006, 24000, 5, 1, 2, '289000.00'),
(34, 'NS-489-AA', 2013, 12000, 5, 5, 1, '511000.00'),
(35, 'NS-999-CC', 2014, 6000, 11, 2, 2, '789000.00'),
(36, 'BC-999 - ZZ', 2015, 3000, 11, 6, 1, '958600.00'),
(100, 'BC - 007 - JB', 2007, 12000, 2, 7, 3, '100500.00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `jarmu_felszereles`
--

CREATE TABLE `jarmu_felszereles` (
  `Jarmu_FelszerelesID` int(11) NOT NULL,
  `FelszerelesID` int(11) DEFAULT NULL,
  `JarmuID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `modell`
--

CREATE TABLE `modell` (
  `ModellID` int(11) NOT NULL,
  `Modell` varchar(100) NOT NULL,
  `GyartoID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `modell`
--

INSERT INTO `modell` (`ModellID`, `Modell`, `GyartoID`) VALUES
(1, 'Astra', 1),
(2, 'Korsa', 1),
(3, 'Insignia', 1),
(4, 'Moka', 1),
(5, 'X1', 2),
(6, 'X3', 2),
(7, 'M6', 2),
(8, 'SLS', 3),
(9, 'CLS', 3),
(10, 'CLK', 3),
(11, 'GTB', 4),
(12, 'Spajder', 4),
(13, 'Punto', 5),
(14, '500', 5);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `szin`
--

CREATE TABLE `szin` (
  `SzinID` int(11) NOT NULL,
  `Szin` varchar(50) NOT NULL,
  `Leiras` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `szin`
--

INSERT INTO `szin` (`SzinID`, `Szin`, `Leiras`) VALUES
(1, 'Bela', NULL),
(2, 'Srebrna', NULL),
(3, 'Crvena', NULL),
(4, 'Zuta', NULL),
(5, 'Plava', NULL),
(6, 'Zelena', NULL),
(7, 'Siva', NULL),
(8, 'Crna', NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `uzemanyag`
--

CREATE TABLE `uzemanyag` (
  `UzemanyagID` int(11) NOT NULL,
  `Uzemanyag` varchar(50) NOT NULL,
  `Leiras` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- A tábla adatainak kiíratása `uzemanyag`
--

INSERT INTO `uzemanyag` (`UzemanyagID`, `Uzemanyag`, `Leiras`) VALUES
(1, 'Evro dizel', NULL),
(2, 'BMB 95', NULL),
(3, 'BMB 98', NULL),
(4, 'Auto gas', NULL);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `felszereles`
--
ALTER TABLE `felszereles`
  ADD PRIMARY KEY (`FelszerelesID`);

--
-- A tábla indexei `gyarto`
--
ALTER TABLE `gyarto`
  ADD PRIMARY KEY (`GyartoID`);

--
-- A tábla indexei `jarmu`
--
ALTER TABLE `jarmu`
  ADD PRIMARY KEY (`JarmuID`),
  ADD KEY `ModelID` (`ModellID`),
  ADD KEY `BojaID` (`SzinID`),
  ADD KEY `GorivoID` (`UzemanyagID`);

--
-- A tábla indexei `jarmu_felszereles`
--
ALTER TABLE `jarmu_felszereles`
  ADD PRIMARY KEY (`Jarmu_FelszerelesID`),
  ADD KEY `FelszerelesID` (`FelszerelesID`),
  ADD KEY `JarmuID` (`JarmuID`);

--
-- A tábla indexei `modell`
--
ALTER TABLE `modell`
  ADD PRIMARY KEY (`ModellID`),
  ADD KEY `ProizvodjacID` (`GyartoID`);

--
-- A tábla indexei `szin`
--
ALTER TABLE `szin`
  ADD PRIMARY KEY (`SzinID`);

--
-- A tábla indexei `uzemanyag`
--
ALTER TABLE `uzemanyag`
  ADD PRIMARY KEY (`UzemanyagID`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `jarmu`
--
ALTER TABLE `jarmu`
  MODIFY `JarmuID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `jarmu`
--
ALTER TABLE `jarmu`
  ADD CONSTRAINT `jarmu_ibfk_1` FOREIGN KEY (`ModellID`) REFERENCES `modell` (`ModellID`),
  ADD CONSTRAINT `jarmu_ibfk_2` FOREIGN KEY (`SzinID`) REFERENCES `szin` (`SzinID`),
  ADD CONSTRAINT `jarmu_ibfk_3` FOREIGN KEY (`UzemanyagID`) REFERENCES `uzemanyag` (`UzemanyagID`);

--
-- Megkötések a táblához `jarmu_felszereles`
--
ALTER TABLE `jarmu_felszereles`
  ADD CONSTRAINT `jarmu_felszereles_ibfk_1` FOREIGN KEY (`FelszerelesID`) REFERENCES `felszereles` (`FelszerelesID`),
  ADD CONSTRAINT `jarmu_felszereles_ibfk_2` FOREIGN KEY (`JarmuID`) REFERENCES `jarmu` (`JarmuID`);

--
-- Megkötések a táblához `modell`
--
ALTER TABLE `modell`
  ADD CONSTRAINT `modell_ibfk_1` FOREIGN KEY (`GyartoID`) REFERENCES `gyarto` (`GyartoID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
